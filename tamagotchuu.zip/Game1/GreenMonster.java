package Game1;

public class GreenMonster extends Monster{

	// monster with set stats
	public GreenMonster(int health, int level, String keyMove) {
		super(health, level, keyMove);
	}
	
	// monster with random stats
	public GreenMonster(int petLevel) {
		
		level = (int) (Math.random() * petLevel); // monster level is random number <= petLevel
		health = (int) (Math.random() * 30);
		keyMove = keyMoves[(int) (Math.random() * 4)]; // chooses one of 4 possible keyMoves from set list
		alive = true;
	}
	
	public void introStats() {
		System.out.println("Your opponent is a green monster!");
		super.introStats();
	}

	@Override
	public void defend() {
		System.out.println("Monster defended");
		lastMove = "defend";
		
	}

	@Override
	public void dodge() {
		System.out.println("Monster dodged");
		lastMove = "dodge";
		
	}

	@Override
	public int attack() {
		int keyMoveTF = (int)(Math.random() * 2);
		
		if (keyMoveTF == 1) {
			System.out.println("Monster attacks with key move!");
			giveDamage = 2 * ((int)(Math.random() * level) + (health / 2)); // random algorithm to determine attack intensity - doubled for key move
		}
		else {
			System.out.println("Monster attacks");
			giveDamage = (int)(Math.random() * level) + (health / 2); // random algorithm to determine attack intensity
		}
		
		System.out.println("Monster inflicted " + giveDamage + " damage");
		return giveDamage;
	}


	@Override
	public void getAttacked(int getDamage) {
		if (lastMove.equals("dodge")) {
			getDamage = 0;
			System.out.println("But Monster dodged the attack! 0 damage");
		}
		else if (lastMove.equals("defend")) {
			getDamage -= getDamage / ((int)(Math.random() * 5) + 1);
			System.out.print("Monster defends the attack. Only received " + getDamage + " damage.");
		}
		health -= getDamage;
		checkHealth();
		if (alive) super.getHealth();
		
		
	}

}
