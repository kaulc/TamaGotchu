package Game1;

import java.util.Scanner;

public class GamePlay {

	static Protagonist p = new Protagonist(50, 3, 15, 4000); // STATS WILL BE IMPORTED FROM OTHER PET CLASSES

	public static void main(String[] args) {

		String tempAns = "";
		int numSteps = 0; // step = # actions taken to find one monster
		int numRounds = 0; // round = # monsters fought to reach final monster
		int stepCounter = 0;
		int roundCounter = 0;

		Scanner sc = new Scanner(System.in);

		// start screen text

		System.out.println("Welcome to - witty game name -");
		System.out.println("You find yourself at the entrance of a castle. You read a sign that states: ");
		System.out.println("- In this castle lies a room of riches. If you find it, you keep it. Enter at your risk.");
		System.out.println("Press [p] to enter the castle and start playing, [s] for stats, or [e] to exit.");

		if (sc.hasNextLine())
			tempAns = sc.nextLine();
		tempAns = tempAns.toLowerCase();

		// NOT NEEDED WHEN WE USE BUTTONS
		while (!tempAns.equals("p")) {
			if (!tempAns.equals("p") && !tempAns.equals("s") && !tempAns.equals("e")) {
				System.out.println("Press [p] to enter the castle and start playing, [s] for stats, or [e] to exit.");
			}
			if (tempAns.equals("e")) {
				System.out.println("Okay thanks for playing, bye");
				break;
			}
			if (tempAns.equals("s")) {
				p.stats();
			}
			if (sc.hasNextLine())
				tempAns = sc.nextLine();
		}

		if (tempAns.equals("p")) {

			System.out.println("You enter the castle.");

			/** ROUND 1 **/

			numRounds = 1; // rounds will be randomly generated
			numSteps = (int) (Math.random() * (numRounds * 3) + 1); // generates num steps for next round based on
																	// current round

			stepCounter = 0;
			while (stepCounter < numSteps) {
				System.out.println("You can either go left, right, or forward. What do you choose? [l/r/f]");
				if (sc.hasNextLine())
					tempAns = sc.nextLine();
				tempAns = tempAns.toLowerCase();
				stepCounter++;
			}

			System.out.println("Oh no! You face a monster. Defeat him to continue your journey in the castle!");

			fightMonster(generateNewMonster(p.getLevel()));

		}
	}

	private static Monster generateNewMonster(int petlevel) {

		// random number generator to choose which monster to randomly create
		GreenMonster gm1 = new GreenMonster(petlevel);
		return gm1;
	}

	private static Boolean fightMonster(Monster m) {
		int petTurn = (int) (Math.random() * 2); // true or false, randomizes who starts fighting first
		String tempAns = "";
		Scanner sc = new Scanner(System.in);

		m.introStats();

		while (p.checkHealth() == true && m.checkHealth() == true) { // fight till someone dies
			if (petTurn == 1) {
				System.out.println();
				System.out.println("It's your turn!");
				System.out.println("Press [j] to defend, [i] to dodge, [l] to attack, or [s] for your stats");

				tempAns = "x";

				while (!tempAns.equals("j") && !tempAns.equals("i") && !tempAns.equals("l")) { // prompt user for proper input
					if (sc.hasNextLine()) {
						tempAns = sc.nextLine();
						tempAns = tempAns.toLowerCase();
					}
					if (tempAns.equals("j")) {
						p.defend();
						break;
					}
					if (tempAns.equals("i")) {
						p.dodge();
						break;
					}
					if (tempAns.equals("l")) {
						p.attack();
						break;
					}
					if (tempAns.equals("s")) {
						p.stats();
					}
					if (!tempAns.equals("j") && !tempAns.equals("i") && !tempAns.equals("l")) {
						System.out.println("Press [j] to defend, [i] to dodge, [l] to attack, or [s] for your stats");
					}
				}
				if (p.checkHealth() == false || m.checkHealth() == false) // if someone dies, break
					break;
				petTurn = 0;
			}
			if (petTurn == 0) {
				System.out.println();
				System.out.println("It's the monster's turn!");
				if (m.act() == 2) p.getAttacked(m.giveDamage);
				
				petTurn = 1;
				if (p.checkHealth() == false || m.checkHealth() == false) // if someone dies, break
					break;
			}

		}
		
		if (p.checkHealth() == false) System.out.println("You died :(");
		else if (m.checkHealth() == false) System.out.println("Monster died!");
		System.out.println("blah");
		return true;

	}

}

/*
 * // REPLACE Y/N WITH BUTTONS if (!tempAns.equals("y") && !tempAns.equals("n"))
 * { while (!tempAns.equals("y") && !tempAns.equals("n")) {
 * System.out.println("Are you up for the challenge? Type [y/n]"); } } if
 * (tempAns.equals("n")) {} // whatever needs to happen to end the game
 */
/*
 * 
 * if (!tempAns.equals("p") && !tempAns.equals("s") && !tempAns.equals("e")) {
 * while (!tempAns.equals("p") && !tempAns.equals("s") && !tempAns.equals("e"))
 * { System.out.
 * println("Press [p] to enter the castle and start playing, [s] for stats, or [e] to exit."
 * ); if (sc.hasNextLine()) tempAns = sc.nextLine(); tempAns =
 * tempAns.toLowerCase(); } }
 */