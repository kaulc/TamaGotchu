package Game1;

public abstract class Monster extends LivingThing implements Action {

	protected String keyMove;
	protected String[] keyMoves = {"Superkick", "Megapunch", "coolaction1", "coolaction2"};
	protected String[] moves = {"kick", "punch", "action1", "action2"};
	
	public Monster(int health, int level, String keyMove) {
		this.health = health;
		this.level = level;
		this.keyMove = keyMove;
		alive = true;
	}
	
	public Monster() {
	}
	
	public void getKeyMove() {
		System.out.println("Key Move: " + keyMove);
	}
	
	public void introStats() {
		System.out.println("Monster health: " + health);
		System.out.println("Monster key move: " + keyMove);
	}
	
	@Override
	public String toString() {
		return keyMove;
		
	}
	
	@Override
	public int act() {
		int chooseAct = (int)(Math.random() * 3);
		if (chooseAct == 0) defend();
		else if (chooseAct == 1) dodge();
		else if (chooseAct == 2) attack();
		return chooseAct;

	}

	
	public Boolean checkHealth() {
		if (health <= 0) {
			alive = false;
		}
		else alive = true;
		return alive;
	}
	
	

}
